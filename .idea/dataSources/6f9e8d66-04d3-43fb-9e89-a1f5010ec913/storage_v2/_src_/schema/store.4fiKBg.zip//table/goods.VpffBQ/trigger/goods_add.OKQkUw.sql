CREATE TRIGGER goods_add
  AFTER INSERT
  ON goods
  FOR EACH ROW
  begin
	set @kindname = new.kind_name;
	update kind set count=count+1 where name=@kindname;
End;

