CREATE TRIGGER goods_del
  AFTER DELETE
  ON goods
  FOR EACH ROW
  begin
	set @kindname = old.kind_name;
	update kind set count=count-1 where name=@kindname;
End;

