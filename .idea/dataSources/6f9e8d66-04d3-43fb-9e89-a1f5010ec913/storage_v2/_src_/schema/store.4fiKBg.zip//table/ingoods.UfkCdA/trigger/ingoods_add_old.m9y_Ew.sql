CREATE TRIGGER ingoods_add_old
  BEFORE INSERT
  ON ingoods
  FOR EACH ROW
  begin
	set new.old_inprice = (select inprice from goods where name=@goodsname);
End;

