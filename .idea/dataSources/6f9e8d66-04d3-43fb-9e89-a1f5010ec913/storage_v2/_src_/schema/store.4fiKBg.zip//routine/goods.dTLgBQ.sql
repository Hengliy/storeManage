CREATE PROCEDURE goods()
  begin
select * from goods;
end;

