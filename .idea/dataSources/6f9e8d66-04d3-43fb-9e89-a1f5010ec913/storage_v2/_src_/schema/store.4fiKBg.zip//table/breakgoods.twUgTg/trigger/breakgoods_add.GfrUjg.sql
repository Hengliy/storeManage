CREATE TRIGGER breakgoods_add
  AFTER INSERT
  ON breakgoods
  FOR EACH ROW
  begin
	set @goodsname = new.goods_name;
	set @out_count = new.count;
	update goods set count=count-@out_count where name=@goodsname;
End;

