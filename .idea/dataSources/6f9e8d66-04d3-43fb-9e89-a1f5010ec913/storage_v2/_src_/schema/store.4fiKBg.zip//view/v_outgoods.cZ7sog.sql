CREATE VIEW v_outgoods AS
  SELECT
    `store`.`outgoods`.`id`          AS `id`,
    `store`.`outgoods`.`num`         AS `num`,
    `store`.`outgoods`.`goods_name`  AS `goods_name`,
    `store`.`goods`.`kind_name`      AS `kind_name`,
    `store`.`goods`.`productor_name` AS `productor_name`,
    `store`.`outgoods`.`count`       AS `count`,
    `store`.`outgoods`.`outdate`     AS `outdate`,
    `store`.`staff`.`username`       AS `username`
  FROM `store`.`outgoods`
    JOIN `store`.`staff`
    JOIN `store`.`goods`
  WHERE ((`store`.`outgoods`.`staff_id` = `store`.`staff`.`id`) AND
         (`store`.`outgoods`.`goods_name` = `store`.`goods`.`name`));

