CREATE TRIGGER outgoods_add
  AFTER INSERT
  ON outgoods
  FOR EACH ROW
  begin
	set @goodsname = new.goods_name;
	set @out_count = new.count;
	update goods set count=count-@out_count where goods_name=@goodsname;
End;

