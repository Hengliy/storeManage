CREATE VIEW v_ingoods AS
  SELECT
    `store`.`ingoods`.`id`           AS `id`,
    `store`.`ingoods`.`goods_name`   AS `goods_name`,
    `store`.`goods`.`kind_name`      AS `kind_name`,
    `store`.`goods`.`productor_name` AS `productor_name`,
    `store`.`ingoods`.`count`        AS `count`,
    `store`.`ingoods`.`inprice`      AS `inprice`,
    `store`.`ingoods`.`indate`       AS `indate`,
    `store`.`staff`.`username`       AS `username`
  FROM `store`.`ingoods`
    JOIN `store`.`staff`
    JOIN `store`.`goods`
  WHERE ((`store`.`ingoods`.`staff_id` = `store`.`staff`.`id`) AND
         (`store`.`ingoods`.`goods_name` = `store`.`goods`.`name`));

