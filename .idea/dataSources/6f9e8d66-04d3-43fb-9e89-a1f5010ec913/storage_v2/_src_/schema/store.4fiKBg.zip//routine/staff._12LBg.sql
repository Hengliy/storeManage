CREATE PROCEDURE staff()
  begin
select * from staff;
end;

