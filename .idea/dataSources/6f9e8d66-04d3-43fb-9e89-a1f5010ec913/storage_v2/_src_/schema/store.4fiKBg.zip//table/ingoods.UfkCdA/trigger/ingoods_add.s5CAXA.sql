CREATE TRIGGER ingoods_add
  AFTER INSERT
  ON ingoods
  FOR EACH ROW
  begin
	set @goodsname = new.goods_name;
	set @in_price = new.inprice;
	set @in_count = new.count;
	update goods set inprice=@in_price,count=count+@in_count where name=@goodsname;
End;

