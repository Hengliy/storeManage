CREATE TRIGGER ingoods_add
  AFTER INSERT
  ON ingoods
  FOR EACH ROW
  begin
	set @ingoodsid = new.id;
	set @goodsname = new.goods_name;
	set @in_price = new.inprice;
	set @in_count = new.count;
	update ingoods set old_inprice=(select inprice from goods where goods_name=@goodsname) where id = @ingoodsid;
	update goods set inprice=@in_price,count=count+@in_count where goods_name=@goodsname;
End;

