CREATE PROCEDURE productor()
  begin
select * from productor;
end;

