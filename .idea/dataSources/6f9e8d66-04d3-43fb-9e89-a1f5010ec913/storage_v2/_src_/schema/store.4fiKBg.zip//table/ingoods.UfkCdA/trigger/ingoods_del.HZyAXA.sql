CREATE TRIGGER ingoods_del
  AFTER DELETE
  ON ingoods
  FOR EACH ROW
  begin
	set @goodsname = old.goods_name;
	set @old_in_price = old.old_inprice;
	set @in_count = old.count;
	update goods set inprice=@old_in_price,count=count-@in_count where goods_name=@goodsname;
End;

