CREATE PROCEDURE breakgoods()
  begin
select * from breakgoods;
end;

