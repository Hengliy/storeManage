CREATE PROCEDURE voutgoods()
  begin
select * from v_outgoods;
end;

