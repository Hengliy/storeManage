CREATE TRIGGER breakgoods_del
  AFTER DELETE
  ON breakgoods
  FOR EACH ROW
  begin
	set @goodsname = old.goods_name;
	set @out_count = old.count;
	update goods set count=count+@out_count where name=@goodsname;
End;

