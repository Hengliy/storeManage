CREATE PROCEDURE vingoods()
  begin
select * from v_ingoods;
end;

